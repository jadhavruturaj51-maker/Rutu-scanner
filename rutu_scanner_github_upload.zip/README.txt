RUTU SCANNER - WEBSITE FILES

Publish with GitHub Pages:
1. Create a new GitHub repository named rutu-scanner.
2. Set repository visibility to Public (required for free GitHub Pages on standard free accounts).
3. Upload index.html to the repository root and commit.
4. Open Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish; the site URL will appear in Settings -> Pages.

Important:
This is a static frontend prototype. It does NOT connect to Angel One SmartAPI and does not produce live trading signals. Never put API keys, PINs, passwords, or TOTP secrets in index.html or a public repository. Live data requires a secure backend.
